// import React from 'react';

const Main = (props) => {
  return props.children;
};

export default Main;
