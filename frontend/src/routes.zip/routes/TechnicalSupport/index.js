// import main from './main';

// const config = {
//   path: 'TechnicalSupport',
//   name: '技术保障支持',
//   target: 'TechnicalSupport', // 用于数据分流 标志 √
//   component: main,
//   childRoutes: [
//     // 技术保障申请
//     // eslint-disable-next-line
//     require('./SupportRequest').default,
//     // 保障请求汇总
//     // eslint-disable-next-line
//     // require('./RequestsSummary').default,
//     // 保障方案
//     // eslint-disable-next-line
//     require('./SupportPlan').default,
//     // 保障任务
//     // eslint-disable-next-line
//     require('./SupportTasks').default,
//     // 在线帮助库
//     // eslint-disable-next-line
//     require('./OnlineHelp').default,
//   ],
// };

// export default config;
import SupportRequest from './SupportRequest/SupportRequest';
import SupportPlan from './SupportPlan/SupportPlan';
import OnlineHelp from './OnlineHelp/OnlineHelp';

const routes = {
  path: 'TechnicalSupport',
  name: '技术保障支持',
  indexRoute: {
    component: SupportRequest,
  },
  childRoutes: [
    {
      path: 'SupportRequest',
      name: '技术保障申请',
      component: SupportRequest,
    }, {
      path: 'SupportPlan',
      name: '技术保障方案',
      component: SupportPlan,
    }, {
      path: 'OnlineHelp',
      name: '在线帮助库',
      component: OnlineHelp,
    },
  ],
};

export default routes;
