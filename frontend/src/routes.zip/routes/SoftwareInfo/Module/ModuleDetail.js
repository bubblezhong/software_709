import React from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';
import './Module.css';

class ModuleDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        { type: '谱系名称:', value: '参数测试软件' },
        { type: '编号:', value: '02' },
        { type: '上级ID:', value: '01-应用软件' },
        { type: '状态:', value: '已激活' },
        { type: '创建人:', value: '张三' },
        { type: '创建时间:', value: '2017/05/01 11:01' },
      ],
    };
  }
  render() {
    const content = this.state.data.map((item, index) => {
      const classname = `MouduleDetail_container_list MouduleDetail_container_list${index}`;
      return (
        <div className={classname} key={index}>
          <span style={{ display: 'inline-block', width: 96 }}>{item.type}</span>
          <span>{item.value}</span>
        </div>
      );
    });
    return (
      <div>
        <div style={{ overflow: 'hidden', marginBottom: 10 }}>
          <Link to="/main/SoftwareInfo/Module" className="MouduleDetail_return">
            <Button style={{ width: 85, height: 30 }}>
              <span style={{ marginRight: 8 }}>&lt;</span>
              <span>返回</span>
            </Button>
          </Link>
          <Link to="/main/SoftwareInfo/ModuleDelete">
            <Button type="primary" className="MouduleDetail_reflash">删除</Button>
          </Link>
          <Link to="/main/SoftwareInfo/ModuleDetailEdit/1">
            <Button type="primary" className="MouduleDetail_reflash">编辑</Button>
          </Link>
        </div>
        <div className="MouduleDetail_container">
          <div className="MouduleDetail_container_title" >
            <h2>详情</h2>
          </div>
          {content}
        </div>
      </div>
    );
  }
}
export default ModuleDetail;
