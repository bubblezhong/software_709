import React from 'react';
import { Link } from 'react-router';
import { Table, Button, Input } from 'antd';

const ButtonGroup = Button.Group;
const Search = Input.Search;
class Module extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{
        key: 1,
        num: '1',
        softname: '远程目标判断软件',
        creator: '张三',
        time: '2017-4-26 16:48',
        state: '未激活',
        children: [{
          key: 11,
          num: '11',
          softname: '远程目标判断软件',
          creator: '张三',
          time: '2017-4-26 16:48',
          state: '未激活',
        }, {
          key: 12,
          num: '12',
          softname: '远程目标判断软件',
          creator: '张三',
          time: '2017-4-26 16:48',
          state: '未激活',
          children: [{
            key: 121,
            num: '121',
            softname: '远程目标判断软件',
            creator: '张三',
            time: '2017-4-26 16:48',
            state: '未激活',
          }],
        }, {
          key: 13,
          num: '13',
          softname: '远程目标判断软件',
          creator: '张三',
          time: '2017-4-26 16:48',
          state: '未激活',
          children: [{
            key: 131,
            num: '131',
            softname: '远程目标判断软件',
            creator: '张三',
            time: '2017-4-26 16:48',
            state: '未激活',
            children: [{
              key: 1311,
              num: '1311',
              softname: '远程目标判断软件',
              creator: '张三',
              time: '2017-4-26 16:48',
              state: '未激活',
            }, {
              key: 1312,
              num: '1312',
              softname: '远程目标判断软件',
              creator: '张三',
              time: '2017-4-26 16:48',
              state: '未激活',
            }],
          }],
        }],
      }, {
        key: 2,
        num: '2',
        softname: '远程目标判断软件',
        creator: '张三',
        time: '2017-4-26 16:48',
        state: '未激活',
      }],
    };
  }
  render() {
    const Btns = (
      <div>
        <ButtonGroup style={{ marginBottom: 10 }}>
          <Button icon="reload" style={{ width: 110, height: 40, fontSize: 14 }}>刷新</Button>
          <Button icon="file-add" style={{ width: 110, height: 40, fontSize: 14 }}>新增</Button>
          <Button icon="login" style={{ width: 110, height: 40, fontSize: 14 }}>导入</Button>
          <Button icon="logout" style={{ width: 110, height: 40, fontSize: 14 }}>导出</Button>
          <Button icon="printer" style={{ width: 110, height: 40, fontSize: 14 }}>打印</Button>
          <Button icon="delete" style={{ width: 110, height: 40, fontSize: 14 }}>删除</Button>
        </ButtonGroup>
        <Search
          style={{ width: 380, height: 40, float: 'right' }}
          onSearch={value => console.log(value)}
        />
      </div>
    );
    const columns = [{
      title: '编号',
      dataIndex: 'num',
      key: 'num',
    }, {
      title: '软件名称',
      dataIndex: 'softname',
      key: 'softname',
    }, {
      title: '创建人',
      dataIndex: 'creator',
      key: 'creator',
    }, {
      title: '创建时间',
      dataIndex: 'time',
      key: 'time',
    }, {
      title: '状态',
      dataIndex: 'state',
      key: 'state',
    }, {
      title: '操作',
      dataIndex: 'operate',
      key: 'operate',
      render: (text, row) => (
        <span>
          <Link to={`/main/SoftwareInfo/ModuleDetail/${row.key}`}>详情</Link>
        </span>
      ),
    }];
  // rowSelection objects indicates the need for row selection
    // const rowSelection = {
    //   onChange: (selectedRowKeys, selectedRows) => {
    //     console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    //   },
    //   onSelect: (record, selected, selectedRows) => {
    //     console.log(record, selected, selectedRows);
    //   },
    //   onSelectAll: (selected, selectedRows, changeRows) => {
    //     console.log(selected, selectedRows, changeRows);
    //   },
    // };
    return (
      <div>
        {Btns}
        <Table
          columns={columns}
          dataSource={this.state.data}
          pagination={{ pageSize: 10 }}
          bordered
        />
      </div>
    );
  }
}

export default Module;
