import React from 'react';
import { browserHistory } from 'react-router';
import { Input, AutoComplete } from 'antd';

const Option = AutoComplete.Option;
class Search extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      historyData: ['中船重工XX所', '中船重工yy所', '中船重工11所', '中船重工22所'],
    };
  }
  render() {
    const option = this.state.historyData.map(opt => (
      <Option key={opt} style={{ marginTop: 20 }}>
        <span className="certain-search-item-count">{opt}</span>
      </Option>
      ));
    return (
      <div style={{ height: 50, borderBottom: '1px solid #ccc', position: 'relative' }}>
        <AutoComplete
          className="certain-category-search"
          dropdownClassName="certain-category-search-dropdown"
          dropdownMatchSelectWidth={false}
          dropdownStyle={{ width: 300 }}
          size="large"
          style={{ width: '30%' }}
          dataSource={option}
          placeholder=" "
          optionLabelProp="value"
        >
          <Input.Search
            placeholder=" "
            style={{ height: 40 }}
            onSearch={value => browserHistory.push(`/main/SoftwareInfo/QueryDetail?value=${value}`)}
          />
        </AutoComplete>
      </div>
    );
  }
}
export default Search;
