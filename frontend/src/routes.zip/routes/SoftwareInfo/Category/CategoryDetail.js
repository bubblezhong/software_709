import React, { PropTypes } from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';
import UseUnit from './UseUnit';
import CategoryVersion from './CategoryVersion';
import CategoryBasicInfo from './CategoryBasicInfo';
import CategoryInfoDetailIntro from './CategoryDetailIntro';
import './Category.css';

const styles = {
  activeCard: {
    color: '#108ee9',
  },
  normalCard: {
    color: '#000',
  },
};
class CategoryInfoDetail extends React.Component {
  constructor(props) {
    super(props);
    const id = this.props.params.id;
    this.state = {
      show: 'CategoryVersion',
      id,
    };
  }
  changeShow = (type) => {
    this.setState({ show: type });
  }
  render() {
    const { show } = this.state;
    const Btns = (
      <div style={{ overflow: 'auto' }}>
        <Link to="/main/SoftwareInfo/Category" className="SoftwareInfoDetail_return">
          <Button style={{ width: 85, height: 30 }}>
            <span style={{ marginRight: 8 }}>&lt;</span>
            <span>返回</span>
          </Button>
        </Link>
        <Link to="/main/SoftwareInfo/SoftwareDetailDelete">
          <Button type="primary" className="SoftwareInfoDetail_reflash">删除</Button>
        </Link>
        <Link to={`/main/SoftwareInfo/CategoryDetailEdit/${this.state.id}`}>
          <Button type="primary" className="SoftwareInfoDetail_reflash">编辑</Button>
        </Link>
      </div>
    );
    const UserTitle = (
      <div className="UserSoftware_title">
        <span onClick={() => this.changeShow('CategoryVersion')} style={show === 'CategoryVersion' ? styles.activeCard : styles.normalCard} >单元版本</span>
        <span>/</span>
        <span onClick={() => this.changeShow('UseUnit')} style={show === 'UseUnit' ? styles.activeCard : styles.normalCard} >使用单位</span>
      </div>
    );
    return (
      <div>
        {Btns}
        <CategoryInfoDetailIntro />
        <CategoryBasicInfo />
        <div>
          {UserTitle}
        </div>
        {this.state.show === 'CategoryVersion' &&
          <CategoryVersion />
        }
        {this.state.show === 'UseUnit' &&
          <UseUnit />
        }
      </div>
    );
  }
}
CategoryInfoDetail.propTypes = {
  params: PropTypes.object.isRequired,
};
export default CategoryInfoDetail;
