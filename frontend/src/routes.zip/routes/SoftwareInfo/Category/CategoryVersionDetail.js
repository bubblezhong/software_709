import React from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';
import CategoryVersionDetailIntro from './CategoryVersionDetail/CategoryVersionDetailIntro';
import CategoryVersionBasicInfo from './CategoryVersionDetail/CategoryVersionBasicInfo';
import CategoryVersionUseUnit from './CategoryVersionDetail/CategoryVersionUseUnit';
import './Category.css';

class CategoryInfoDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: 'CategoryVersion',
    };
  }
  render() {
    return (
      <div>
        <div style={{ overflow: 'auto' }}>
          <Link to="/main/SoftwareInfo/CategoryDetail/1" className="SoftwareInfoDetail_return">
            <Button style={{ width: 85, height: 30 }}>
              <span style={{ marginRight: 8 }}>&lt;</span>
              <span>返回</span>
            </Button>
          </Link>
          <Link to="/main/SoftwareInfo/SoftwareDetailDelete">
            <Button type="primary" className="SoftwareInfoDetail_reflash">刷新</Button>
          </Link>
        </div>
        <CategoryVersionDetailIntro />
        <CategoryVersionBasicInfo />
        <CategoryVersionUseUnit />
      </div>
    );
  }
}
export default CategoryInfoDetail;
