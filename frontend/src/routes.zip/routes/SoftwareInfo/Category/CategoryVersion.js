

import React from 'react';
import { Button } from 'antd';
import CategoryVersionTable from './CategoryVersionTable';
import CategoryVersionTimetree from './CategoryVersionTimetree';
import './Category.css';

class CategoryVersion extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: 'CategoryVersionTimetree',
      value: '列表模式',
    };
  }
  changeshow() {
    if (this.state.show === 'CategoryVersionTimetree') {
      console.log(this.state.show);
      this.setState({ show: 'CategoryVersionTable', value: '时间轴模式' });
    } else {
      console.log('1111');
      console.log(this.state.show);
      this.setState({ show: 'CategoryVersionTimetree', value: '列表模式' });
    }
  }
  render() {
    const Btns = (
      <div className="SoftwareVersion_changeformat">
        <Button onClick={() => this.changeshow()} >{this.state.value}</Button>
      </div>
    );
    return (
      <div>
        {Btns}
        { this.state.show === 'CategoryVersionTimetree' && <CategoryVersionTimetree /> }
        { this.state.show === 'CategoryVersionTable' && <CategoryVersionTable /> }
      </div>
    );
  }
}
export default CategoryVersion;
