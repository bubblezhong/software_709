import React, { PropTypes } from 'react';
import { Link } from 'react-router';
import { Button, Form, Input, Select, Row, Radio, Upload, Icon, Col, Switch, TreeSelect } from 'antd';
import './SoftwareDetail.css';

const FormItem = Form.Item;
const SHOW_PARENT = TreeSelect.SHOW_PARENT;
const Option = Select.Option;
// const TreeNode = TreeSelect.TreeNode;
class SoftwareVersionDetailEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      treeData: [{
        label: '声呐定位指示软件',
        value: '0-0',
        key: '0-0',
        children: [{
          label: '优化模块',
          value: '0-0-0',
          key: '0-0-0',
        }, {
          label: '优化模块1',
          value: '0-0-1',
          key: '0-0-1',
        }],
      }, {
        label: '优化模块',
        value: '0-1',
        key: '0-1',
        children: [{
          label: '目标指示模块',
          value: '0-1-0',
          key: '0-1-0',
        }, {
          label: '声呐控制',
          value: '0-1-1',
          key: '0-1-1',
        }, {
          label: '总体模块',
          value: '0-1-2',
          key: '0-1-2',
        }],
      }],
      initialData: {
        softwareName: '应用软件',
        number: 'CL-20170427-0001',
        ancestary: [],
        moduleRelation: ['应用软件->C类应用软件->对下声呐定位'],
        developUnit: '中船444',
        represent: '中船444',
        OperateSystem: [],
        representInstallPos: [],
        saveType: '11',
        savePos: '11',
        active: '11',
        softwareDescription: '无',
      },
      ancestaryTreeData: [{
        label: '应用软件',
        value: '0-0',
        key: '0-0',
        children: [{
          label: '参数测量软件',
          value: '0-0-1',
          key: '0-0-1',
        }, {
          label: '参数测量软件',
          value: '0-0-2',
          key: '0-0-2',
        }],
      }, {
        label: '参数测量软件',
        value: '0-1',
        key: '0-1',
      }],
      addStatus: false,
    };
  }
  componentWillMount() {
    console.log('edit', this.props);
    if (this.props.location.pathname === '/main/SoftwareInfo/SoftwareDetailAdd') {
      this.setState({ initialData: {} });
    } else {
      this.setState({ initialData: {
        softwareName: '应用软件',
        number: 'CL-20170427-0001',
        ancestary: '软件谱系>应用软件',
        moduleRelation: ['应用软件->C类应用软件->对下声呐定位'],
        developUnit: '中船444',
        represent: '中船444',
        OperateSystem: ['window'],
        representInstallPos: ['111'],
        saveType: '11',
        savePos: '11',
        active: '11',
        softwareDescription: '无',
      } });
    }
  }
  render() {
    const { initialData } = this.state;
    const { getFieldDecorator } = this.props.form;
    const tProps = {
      treeData: this.state.treeData,
      multiple: true,
      treeCheckable: true,
      showCheckedStrategy: SHOW_PARENT,
      style: {
        width: 300,
      },
    };
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const formItemLayoutDesc = {
      labelCol: { span: 3 },
      wrapperCol: { span: 19 },
    };
    return (
      <div>
        <div style={{ overflow: 'auto', marginBottom: 20 }}>
          <Link to="/main/SoftwareInfo/SoftwareInfoDetail/1" className="SoftwareInfoDetail_return">
            <Button style={{ width: 85, height: 30 }}>
              <span style={{ marginRight: 8 }}>&lt;</span>
              <span>返回</span>
            </Button>
          </Link>
          <Link to="/main/SoftwareInfo/SoftwareInfoDetail/SoftwareDetailEdit">
            <Button type="primary" className="SoftwareInfoDetail_reflash">完成</Button>
          </Link>
        </div>
        <Form onSubmit={this.handleSubmit}>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '5%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件基本信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件名称"
                hasFeedback
              >
                {getFieldDecorator('softwarename', {
                  initialValue: initialData.softwareName,
                  rules: [{
                    required: true, message: '请输入软件名称!',
                  }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="编号"
                hasFeedback
              >
                {getFieldDecorator('number', {
                  initialValue: initialData.number,
                  rules: [{
                    required: true, message: '请输入编号!',
                  }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="谱系"
                hasFeedback
              >
                {getFieldDecorator('ancestary', {
                  initialValue: initialData.ancestary,
                  rules: [{ required: true, message: '请输入谱系!' }],
                })(
                  <TreeSelect
                    style={{ width: 467 }}
                    value={this.state.value}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.ancestaryTreeData}
                    treeDefaultExpandAll
                    onChange={this.onChange}
                  />
                )}
              </FormItem>
            </Col>
            <Col span={12} className="moduleRelation">
              <FormItem
                {...formItemLayout}
                label="软件模块关系"
                hasFeedback
              >
                {getFieldDecorator('moduleRelation', {
                  initialValue: initialData.moduleRelation,
                  rules: [
                    { required: true, message: '请输入软件模块关系', type: 'array' },
                  ],
                })(
                  <TreeSelect style={{ width: 450 }} {...tProps} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '5%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>单位基本信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="研制单位"
                hasFeedback
              >
                {getFieldDecorator('developUnit', {
                  initialValue: initialData.developUnit,
                  rules: [
                    { required: true, message: '请输入研制单位!' },
                  ],
                })(
                  <Select>
                    <Option value="01-xx中队指挥所">01-xx中队指挥所</Option>
                    <Option value="02-yy中队指挥所">02-yy中队指挥所</Option>
                    <Option value="03-yy中队指挥所">03-yy中队指挥所</Option>
                    <Option value="04-yy中队指挥所">04-yy中队指挥所</Option>
                    <Option value="05-yy中队指挥所">05-yy中队指挥所</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="军代表"
                hasFeedback
              >
                {getFieldDecorator('represent', {
                  initialValue: initialData.represent,
                  rules: [{ required: true, message: '请选择军代表!' }],
                })(
                  <Select>
                    <Option value="01-登记员A类">01-登记员A类</Option>
                    <Option value="02-维护员B类">02-维护员B类</Option>
                    <Option value="03-审批员B类">03-审批员B类</Option>
                    <Option value="04-登记员C类">04-登记员C类</Option>
                    <Option value="05-审批员C类">05-审批员C类</Option>
                    <Option value="06-维护员D类">06-维护员D类</Option>
                    <Option value="07-审批员C类">07-审批员C类</Option>
                    <Option value="08-登记员D类">08-登记员D类</Option>

                  </Select>
                )}
              </FormItem>
            </Col>
          </Row>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '5%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件描述信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="操作系统"
                hasFeedback
              >
                {getFieldDecorator('OperateSystem', {
                  initialValue: initialData.OperateSystem,
                  rules: [
                    { required: true, message: '请输入操作系统!', type: 'array' },
                  ],
                })(
                  <Select mode="multiple">
                    <Option value="radhat">radhat</Option>
                    <Option value="linux">linux</Option>
                    <Option value="centOS">centOS</Option>
                    <Option value="Windows">Windows</Option>
                    <Option value="塞班">塞班</Option>
                    <Option value="Android">Android</Option>
                    <Option value="ubuntu">ubuntu</Option>
                    <Option value="其他">其他</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="典型安装位置"
                hasFeedback
              >
                {getFieldDecorator('representInstallPos', {
                  initialValue: initialData.representInstallPos,
                  rules: [
                    { required: true, message: '请输入典型安装位置!', type: 'array' },
                  ],
                })(
                  <Select mode="multiple">
                    <Option value="中控板">中控板</Option>
                    <Option value="交叉控制板">交叉控制板</Option>
                    <Option value="指挥中心">指挥中心</Option>
                    <Option value="其他">其他</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="存储位置"
                hasFeedback
              >
                {getFieldDecorator('savePos', {
                  initialValue: initialData.savePos,
                  rules: [{
                    required: true, message: '请输入存储位置',
                  }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="存储方式"
              >
                {getFieldDecorator('saveType', {
                  initialValue: initialData.saveType,
                  rules: [{ required: true, message: '请输入存储方式' }],
                })(
                  <Radio.Group>
                    <Radio value="自持">自持</Radio>
                    <Radio value="网络存储">网络存储</Radio>
                  </Radio.Group>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="激活"
              >
                {getFieldDecorator('active', {
                  initialValue: initialData.active,
                  rules: [{ required: true, message: '请选择是否激活' }],
                })(
                  <Switch defaultChecked={false} />,
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="附件"
              >
                {getFieldDecorator('file', {
                  rules: [{ required: true, message: '请点击上传附件' }],
                })(
                  <Upload>
                    <Button>
                      <Icon type="upload" />点击上传
                    </Button>
                  </Upload>
                )}
              </FormItem>
            </Col>
            <Col span={24}>
              <FormItem
                {...formItemLayoutDesc}
                label="软件描述"
                hasFeedback
              >
                {getFieldDecorator('softwareDescription', {
                  initialValue: initialData.softwareDescription,
                  rules: [{ required: true, message: '请输入软件描述' }],
                })(
                  <Input type="textarea" rows={10} />
                )}
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    );
  }
}

SoftwareVersionDetailEdit.propTypes = {
  form: PropTypes.object.isRequired,
  location: PropTypes.object.isRequired,
};
const WrapSoftwareVersionDetailEdit = Form.create()(SoftwareVersionDetailEdit);
export default WrapSoftwareVersionDetailEdit;
