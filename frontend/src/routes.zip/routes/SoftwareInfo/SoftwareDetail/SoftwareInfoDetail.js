import React, { PropTypes } from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';
import UseUnit from './UseUnit';
import SoftwareVersion from './SoftwareVersion';
import SoftwareBasicInfo from './SoftwareBasicInfo';
import SoftwareInfoDetailIntro from './SoftwareInfoDetailIntro';
import './SoftwareDetail.css';

const styles = {
  activeCard: {
    color: '#108ee9',
  },
  normalCard: {
    color: '#000',
  },
};
class SoftwareInfoDetail extends React.Component {
  constructor(props) {
    super(props);
    const id = this.props.params.id;
    console.log('detail', this.props);
    this.state = {
      show: 'SoftwareVersion',
      id,
    };
  }
  changeShow = (type) => {
    this.setState({ show: type });
  }
  render() {
    const { show } = this.state;
    const Btns = (
      <div style={{ overflow: 'hidden', marginBottom: 20 }}>
        <Link to="/main/SoftwareInfo/SoftwareDetail" className="SoftwareInfoDetail_return">
          <Button style={{ width: 85, height: 30 }}>
            <span style={{ marginRight: 8 }}>&lt;</span>
            <span>返回</span>
          </Button>
        </Link>
        <Link to="/main/SoftwareInfo/SoftwareDetailDelete">
          <Button type="primary" className="SoftwareInfoDetail_reflash">删除</Button>
        </Link>
        <Link to={`/main/SoftwareInfo/SoftwareDetailEdit/${this.state.id}`}>
          <Button type="primary" className="SoftwareInfoDetail_reflash">编辑</Button>
        </Link>
      </div>
    );
    const UserTitle = (
      <div className="UserSoftware_title">
        <span onClick={() => this.changeShow('SoftwareVersion')} style={show === 'SoftwareVersion' ? styles.activeCard : styles.normalCard} >软件版本</span>
        <span>/</span>
        <span onClick={() => this.changeShow('UseUnit')} style={show === 'UseUnit' ? styles.activeCard : styles.normalCard} >使用单位</span>
      </div>
    );
    return (
      <div>
        {Btns}
        <SoftwareInfoDetailIntro />
        <SoftwareBasicInfo />
        <div>
          {UserTitle}
        </div>
        {this.state.show === 'SoftwareVersion' &&
          <SoftwareVersion />
        }
        {this.state.show === 'UseUnit' &&
          <UseUnit />
        }
      </div>
    );
  }
}
SoftwareInfoDetail.propTypes = {
  params: PropTypes.number.isRequired,
};
export default SoftwareInfoDetail;
