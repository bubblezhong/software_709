import React from 'react';
import { Button } from 'antd';
import { Link } from 'react-router';
import SoftwareVersionTable from './SoftwareVersionTable';
import SoftwareVersionTimetree from './SoftwareVersionTimetree';
import './SoftwareDetail.css';

class SoftwareVersion extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: 'SoftwareVersionTimetree',
      value: '列表模式',
    };
  }
  changeshow() {
    if (this.state.show === 'SoftwareVersionTimetree') {
      this.setState({ show: 'SoftwareVersionTable', value: '时间轴模式' });
    } else {
      this.setState({ show: 'SoftwareVersionTimetree', value: '列表模式' });
    }
  }
  render() {
    const Btns = (
      <div className="SoftwareVersion_changeformat">
        <Link to="/main/SoftwareInfo/SoftwareAddVersion">
          <Button>添加版本</Button>
        </Link>
        <Button onClick={() => this.changeshow()} >{this.state.value}</Button>
      </div>
    );
    return (
      <div>
        {Btns}
        { this.state.show === 'SoftwareVersionTimetree' && <SoftwareVersionTimetree /> }
        { this.state.show === 'SoftwareVersionTable' && <SoftwareVersionTable /> }
      </div>
    );
  }
}
export default SoftwareVersion;
