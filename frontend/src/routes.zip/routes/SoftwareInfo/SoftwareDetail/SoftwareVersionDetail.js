import React from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';
import SoftwareVersionUseUnit from './SoftwareVersionDetail/SoftwareVersionUseUnit';
import SoftwareVersionDetailIntro from './SoftwareVersionDetail/SoftwareVersionDetailIntro';
import SoftwareVersionBasicInfo from './SoftwareVersionDetail/SoftwareVersionBasicInfo';
import SoftwareVersionDetailEdit from './SoftwareVersionDetail/SoftwareVersionDetailEdit';
import './SoftwareDetail.css';

class SoftwareVersionDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: 'SoftwareVersion',
      editStatus: false,
    };
  }
  retrunUnEdit = () => {
    this.setState({ editStatus: false });
  }
  render() {
    return (
      <div>
        {this.state.editStatus ?
          <SoftwareVersionDetailEdit retrunUnEdit={() => { this.retrunUnEdit(); }} /> :
            <div>
              <div style={{ overflow: 'hidden', marginBottom: 20 }}>
                <Link to="/main/SoftwareInfo/SoftwareInfoDetail/2" className="SoftwareInfoDetail_return">
                  <Button style={{ width: 85, height: 30 }}>
                    <span style={{ marginRight: 8 }}>&lt;</span>
                    <span>返回</span>
                  </Button>
                </Link>
                <Link to="/main/SoftwareInfo/SoftwareDetailDelete">
                  <Button type="primary" className="SoftwareInfoDetail_reflash">删除</Button>
                </Link>
                <Button type="primary" className="SoftwareInfoDetail_reflash" onClick={() => { this.setState({ editStatus: true }); }}>编辑</Button>
              </div>
              <SoftwareVersionDetailIntro />
              <SoftwareVersionBasicInfo />
              <SoftwareVersionUseUnit />
            </div>
        }
      </div>
    );
  }
}
export default SoftwareVersionDetail;
