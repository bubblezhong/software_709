import React from 'react';
import { browserHistory, Link } from 'react-router';
import { Table, Button, Input } from 'antd';

const Search = Input.Search;
const ButtonGroup = Button.Group;
class SoftwareDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{
        key: '1',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '2',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '3',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '4',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '5',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '6',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '7',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '8',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '9',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        devUnit: '中船重工XXX研究所',
        status: '已激活',
        detail: '详情',
      }, {
        key: '10',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '11',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }, {
        key: '12',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        devUnit: '中船重工XXX研究所',
        time: '2017/5/18 20:39',
        status: '已激活',
        detail: '详情',
      }],
    };
  }
  render() {
    const columns = [{
      title: '编号',
      dataIndex: 'number',
    }, {
      title: '谱系',
      dataIndex: 'ancestry',
    }, {
      title: '软件名称',
      dataIndex: 'name',
    }, {
      title: '研制单位',
      dataIndex: 'devUnit',
    }, {
      title: '创建时间',
      dataIndex: 'time',
    }, {
      title: '状态',
      dataIndex: 'status',
    }, {
      title: '操作',
      dataIndex: 'detail',
      render: (text, row) => <Link to={`/main/SoftwareInfo/SoftwareInfoDetail/${row.key}`}>{text}</Link>,
    }];
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };
    return (
      <div>
        <div>
          <ButtonGroup style={{ marginBottom: 10 }}>
            <Button icon="reload" style={{ width: 110, height: 40, fontSize: 14 }}>刷新</Button>
            <Button onClick={() => browserHistory.push('/main/SoftwareInfo/SoftwareDetailAdd')} icon="file-add" style={{ width: 110, height: 40, fontSize: 14 }}>新增</Button>
            <Button icon="login" style={{ width: 110, height: 40, fontSize: 14 }}>导入</Button>
            <Button icon="logout" style={{ width: 110, height: 40, fontSize: 14 }}>导出</Button>
            <Button icon="printer" style={{ width: 110, height: 40, fontSize: 14 }}>打印</Button>
            <Button icon="delete" style={{ width: 110, height: 40, fontSize: 14 }}>删除</Button>
          </ButtonGroup>
          <Search
            style={{ width: 380, height: 40, float: 'right' }}
            onSearch={value => console.log(value)}
          />
        </div>
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={this.state.data}
          pagination={{ pageSize: 10 }}
          bordered
        />
      </div>
    );
  }
}
export default SoftwareDetail;
