import React from 'react';
import { Table } from 'antd';
import { Link } from 'react-router';
import './UnitInfo.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{
        key: '1',
        sort: '01',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '2',
        sort: '02',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '3',
        sort: '03',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '4',
        sort: '04',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '5',
        sort: '05',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '6',
        sort: '06',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '7',
        sort: '07',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '8',
        sort: '08',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }, {
        key: '9',
        sort: '09',
        number: 'CL-20170427-0001',
        ancestry: '应用软件>C类应用软件>对下声呐定位',
        name: '远程目标判断软件',
        time: '2017/5/18 20:39',
        status: '待录入',
        operate: '详情',
      }],
    };
  }
  render() {
    const columns = [{
      title: '序号',
      dataIndex: 'sort',
    }, {
      title: '软件编号',
      dataIndex: 'number',
    }, {
      title: '谱系',
      dataIndex: 'ancestry',
    }, {
      title: '软件名称',
      dataIndex: 'name',
    }, {
      title: '版本',
      dataIndex: 'version',
    }, {
      title: '出库时间',
      dataIndex: 'time',
    }, {
      title: '状态',
      dataIndex: 'status',
    }, {
      title: '详情',
      dataIndex: 'operate',
      render: text => <Link to="/main/SoftwareInfo/SoftwareInfoDetail/1">{text}</Link>,
    }];
    return (
      <div>
        <Table
          columns={columns}
          dataSource={this.state.data}
          bordered
        />
      </div>
    );
  }
}


export default App;
