import React from 'react';
import { Link } from 'react-router';
import { Table, Button, Input } from 'antd';
import './UnitInfo.css';

const ButtonGroup = Button.Group;
const Search = Input.Search;
class InfoShow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{
        key: '1',
        number: '01',
        unit: '中船重工709所',
        source: '研发单位',
        manager: '张三',
        detail: '详情',
        time: '2017/5/18 20:39',
      }, {
        key: '2',
        number: '02',
        unit: '中船重工722所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '使用单位',
        detail: '详情',
      }, {
        key: '3',
        number: '03',
        unit: '中船重工762所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '日常管理部门',
        detail: '详情',
      }, {
        key: '4',
        number: '04',
        unit: '510',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }, {
        key: '5',
        number: '05',
        unit: '520',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '使用单位',
        detail: '详情',
      }, {
        key: '6',
        number: '06',
        unit: '560',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '使用单位',
        detail: '详情',
      }, {
        key: '7',
        number: '07',
        unit: '590',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }, {
        key: '8',
        number: '08',
        unit: 'XX中队指挥所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }, {
        key: '9',
        number: '09',
        unit: 'XX中队指挥所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }, {
        key: '10',
        number: '10',
        unit: 'XX中队指挥所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }, {
        key: '11',
        number: '11',
        unit: 'XX中队指挥所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }, {
        key: '12',
        number: '12',
        unit: '中船重工762所',
        manager: '张三',
        time: '2017/5/18 20:39',
        source: '管理机关',
        detail: '详情',
      }],
    };
  }
  render() {
    const Btns = (
      <div>
        <ButtonGroup style={{ marginBottom: 10 }}>
          <Button icon="reload" style={{ width: 110, height: 40, fontSize: 14 }}>刷新</Button>
          <Button icon="logout" style={{ width: 110, height: 40, fontSize: 14 }}>导出</Button>
          <Button icon="printer" style={{ width: 110, height: 40, fontSize: 14 }}>打印</Button>
        </ButtonGroup>
        <Search
          style={{ width: 380, height: 40, float: 'right' }}
          onSearch={value => console.log(value)}
        />
      </div>
    );
    const columns = [{
      title: '编号',
      dataIndex: 'number',
    }, {
      title: '单位',
      dataIndex: 'unit',
    }, {
      title: '来源',
      dataIndex: 'source',
    }, {
      title: '负责人',
      dataIndex: 'manager',
    }, {
      title: '时间',
      dataIndex: 'time',
    }, {
      title: '详情',
      dataIndex: 'detail',
      render: (text, row) => <Link to={`/main/SoftwareInfo/UnitDetail/${row.key}`}>{text}</Link>,
    }];
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };
    return (
      <div>
        {Btns}
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={this.state.data}
          pagination={{ pageSize: 10 }}
        />
      </div>
    );
  }
}
export default InfoShow;
