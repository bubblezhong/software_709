import React from 'react';
import { Link } from 'react-router';
import { Button, Icon } from 'antd';
import './UnitInfo.css';
import UseSoftware from './UseSoftware';
import DevelopSoftware from './DevelopSoftware';

const styles = {
  activeCard: {
    color: '#108ee9',
  },
  normalCard: {
    color: '#000',
  },
};
class UnitDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      content: '七○二所，1951年建立于上海黄浦江畔，1965年总部搬迁至无锡，在上海设有分部和青岛分部。数十年来建有功能齐全、配套完整的大中型科研试验设施近30座，设有两个国家级重点实验室，两个国家级检测中心，一个国家能源海洋工程装备研发中心和一个省级重点实验室，占地1300余亩，现有职工1500余人，其中拥有中国工程院院士2名， 国家“千人计划”1人，“万人计划”1人，“新世纪百千万人才工程”重点培养对象2人，国防科技工业511人才工程学术带头人2人，享受国务院政府津贴专家42名，省部级有突出贡献中青年专家19名。',
      data: [
        { name: '升级完善', val: 23 },
        { name: '技术保障', val: 621 },
        { name: '出入库登记', val: 50 },
        { name: '研发软件', val: 320 },
      ],
      show: 'UseSoftware',
    };
  }
  changeShow = (type) => {
    this.setState({ show: type });
  }
  render() {
    const { show } = this.state;
    const staticProp = [
      { name: '升级完善', icon: 'exclamation-circle' },
      { name: '技术保障', icon: 'code-o' },
      { name: '出入库登记', icon: 'schedule' },
      { name: '研发软件', icon: 'database' },
    ];
    const Btns = (
      <div style={{ overflow: 'hidden', marginBottom: 20 }}>
        <Link to="/main/SoftwareInfo/UnitInfo" className="UnitDetail_return">
          <Button style={{ width: 85, height: 30 }}>
            <span style={{ marginRight: 8 }}>&lt;</span>
            <span>返回</span>
          </Button>
        </Link>
        <Button type="primary" className="UnitDetail_reflash">刷新</Button>
      </div>
    );
    const Detail = (
      <div className="UnitDetail_detail" >
        <div className="UnitDetail_headerpic">
          <span>单位</span>
        </div>
        <div className="uniteDetail_content">
          <h2>中船重工709研究所</h2>
          <div>
            {this.state.content}
          </div>
        </div>
      </div>
    );
    const UserTitle = (
      <div className="UserSoftware_title">
        <span onClick={() => this.changeShow('UseSoftware')} style={show === 'UseSoftware' ? styles.activeCard : styles.normalCard} >使用软件</span>
        <span>/</span>
        <span onClick={() => this.changeShow('DevelopSoftware')} style={show === 'DevelopSoftware' ? styles.activeCard : styles.normalCard} >研发软件</span>
      </div>
    );
    const InfoStatistics = this.state.data.map((item, index) => {
      return (
        <div key={index} className="UnitDetail_contentli">
          <Icon type={staticProp[index].icon} style={{ fontSize: 30, color: '#4d79fa' }} />
          <span style={{ marginLeft: 10 }}>{staticProp[index].name}</span>
          <span style={{ fontSize: 22 }}>{item.val}</span>
        </div>
      );
    });
    return (
      <div>
        { Btns }
        { Detail }
        <div className="UnitDetail_InfoStatistics">
          <h2>信息统计</h2>
          {InfoStatistics}
        </div>
        <div>
          {UserTitle}
        </div>
        {this.state.show === 'UseSoftware' &&
          <UseSoftware />
        }
        {this.state.show === 'DevelopSoftware' &&
          <DevelopSoftware />
        }
      </div>
    );
  }
}
export default UnitDetail;
