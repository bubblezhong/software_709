import main from './main';

const config = {
  path: 'UpgradeRequest',
  name: '升级需求上报',
  component: main,
};

export default config;
