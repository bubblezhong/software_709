// import main from './main';

// const config = {
//   path: 'UpgradePerfect',
//   name: '升级完善管理',
//   target: 'UpgradePerfect', // 用于数据分流 标志 √
//   component: main,
//   childRoutes: [
//     // 升级需求收集
//     // eslint-disable-next-line
//     require('./UpgradeRequest').default,
//     // 升级需求汇总
//     // eslint-disable-next-line
//     require('./RequestsSummary').default,
//     // 升级需求任务
//     // eslint-disable-next-line
//     require('./UpgradeTasks').default,
//     // 升级需求论证
//     // eslint-disable-next-line
//     require('./UpgradeArgument').default,
//     // 升级信息记录
//     // eslint-disable-next-line
//     require('./UpgradeNotes').default,
//   ],
// };

// export default config;
import UpgradeRequest from './UpgradeRequest/UpgradeRequest';
import UpgradeSummary from './UpgradeSummary/UpgradeSummary';
import UpgradeApply from './UpgradeApply/UpgradeApply';
import UpgradeScheme from './UpgradeScheme/UpgradeScheme';

const routes = {
  path: 'UpgradePerfect',
  name: '升级完善管理',
  indexRoute: {
    component: UpgradeRequest,
  },
  childRoutes: [
    {
      path: 'UpgradeRequest',
      name: '升级完善上报',
      component: UpgradeRequest,
    }, {
      path: 'UpgradeSummary',
      name: '升级完善汇总',
      component: UpgradeSummary,
    }, {
      path: 'UpgradeApply',
      name: '技术保障申请',
      component: UpgradeApply,
    }, {
      path: 'UpgradeScheme',
      name: '技术保障方案',
      component: UpgradeScheme,
    },
  ],
};

export default routes;
