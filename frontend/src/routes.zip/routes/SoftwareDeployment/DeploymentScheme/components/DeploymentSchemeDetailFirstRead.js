import { Table, Input, Button, Icon } from 'antd';
import React from 'react';
import { Link } from 'react-router';
import '../DeploymentScheme.css';
// import { json2table } from './json2table';

const Search = Input.Search;
class DeploymentSchemeDetailFirstRead extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      InitialData: {
        content: '七○二所，1951年建立于上海黄浦江畔，1965年总部搬迁至无锡，在上海设有分部和青岛分部。数十年来建有功能齐全、配套完整的大中型科研试验设施近30座，设有两个国家级重点实验室，两个国家级检测中心，一个国家能源海洋工程装备研发中心和一个省级重点实验室，占地1300余亩，现有职工1500余人，其中拥有中国工程院院士2名， 国家“千人计划”1人，“万人计划”1人，“新世纪百千万人才工程”重点培养对象2人，国防科技工业511人才工程学术带头人2人，享受国务院政府津贴专家42名，省部级有突出贡献中青年专家19名。',
        number: 'MSSXL0678',
        developmentUnit: '中岸用软件-709所',
        softwareName: 'XX软件',
        file: ['附件1', '附件2'],
        status: '定制中',
        time: '2017/05/12',
      },
      dataSource: [{
        key: '1',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '2',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '3',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '4',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '5',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '6',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '7',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '8',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '9',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }],
      deploymentSchemeData: [{
        key: '033',
        num: '0',
        softwarePos: '岸基指挥所',
        softwareType: '',
        moduleInfo: '',
        children: [
          {
            key: '020',
            num: '00',
            softwarePos: 'XX指挥所',
            softwareType: '',
            moduleInfo: '',
            children: [
              {
                key: '0020',
                num: '000',
                softwarePos: '主控板0',
                softwareType: '岸用软件',
                moduleInfo: '总体模块、xx模块、xx模块',
              }, {
                key: '0230',
                num: '0021',
                softwarePos: '主控板1',
                softwareType: '岸用软件',
                moduleInfo: '总体模块、xx模块、xx模块',
              }, {
                key: '0220',
                num: '0022',
                softwarePos: '主控板2',
                softwareType: '岸用软件',
                moduleInfo: '总体模块、xx模块、xx模块',
              },
            ],
          },
        ],
      }],
      temp: 0,
    };
  }
  componentDidMount() {
    // const fatherkey = '';
    // this.setKey(this.state.deploymentSchemeData, fatherkey, this.state.temp);
  }
  // createKey = (data, fatherkey) => {
  //   for (let i = 0; i < data.length; i++) {
  //     data[i].key = fatherkey.toString + i;
  //     if (data[i].children) {
  //       this.createKey(data[i].children, data[i].key);
  //     } else {
  //       return;
  //     }
  //   }
  //   console.log(data);
  // }
  setKey = (dataNow, fatherKey) => {
    console.log(fatherKey);
    for (let ii = 0; ii < dataNow.length; ii++) {
      dataNow[ii].key = fatherKey + ii;
      if (dataNow[ii].children) {
        this.setKey(dataNow[ii].children, dataNow[ii].key);
      } else if (fatherKey.length === 2) {
        for (let j = 0; j < dataNow.length; j++) {
          dataNow[j].key = fatherKey + j;
        }
      } else {
        return;
      }
    }
    return dataNow;
  }
  copy = (row) => {
    const fatherkey = '';
    // const row = this.setKey(row1, fatherkey);
    // console.log('row', row);
    const tempData = this.state.deploymentSchemeData; // 001
    let tempI = 0;
    const key = row.key;
    const len = key.length;
    const index1 = parseInt(key.substring(tempI++, 1), 10);
    let cloneData = tempData[index1];
    console.log('cloneData', cloneData);
    if (cloneData.children) {
      for (let i = 0; i < len - 1; i++) {
        const index = parseInt(key.substring(tempI++, 1), 10);
        cloneData = cloneData.children[index];
      }
    }
    if (len === 1) {
      tempData.push(cloneData);
    } else if (len === 2) {
      const fatherIndex = parseInt(key.substring(0, 1), 10);
      tempData[fatherIndex].children.push(cloneData);
    } else {
      const fatherIndex = parseInt(key.substring(1, 1), 10);
      tempData[fatherIndex].children.push(cloneData);
    }
    const realData = this.setKey(tempData, fatherkey);
    console.log('realData', realData);
    this.setState({ deploymentSchemeData: realData });
  }
  render() {
    const { InitialData } = this.state;
    const columns = [{
      title: '编号',
      dataIndex: 'number',
    }, {
      title: '调配申请标题',
      dataIndex: 'title',
    }, {
      title: '申请单位',
      dataIndex: 'unit',
    }, {
      title: '申请人',
      dataIndex: 'applicant',
    }, {
      title: '申请时间',
      dataIndex: 'time',
    }, {
      title: '操作',
      dataIndex: 'operate',
      render: (text, row) => <Link to={`/main/SoftwareDeployment/DeploymentRequestDetail/${row.key}`}>{text}</Link>,
    }];
    const deploymentSchemeColumns = [{
      title: '软件安装位置',
      dataIndex: 'softwarePos',
      key: 'softwarePos',
    }, {
      title: '操作',
      dataIndex: 'operate',
      key: 'operate',
      render: (text, record, index) => {
        console.log('row189', text, record, index);
        return (
          <span className="DeploymentSchemeDetailFirst_editButton">
            <Icon style={{ color: '#48db97' }} type="plus" />
            <Icon style={{ color: '#fab54e' }} type="edit" />
            <Icon onClick={() => { this.copy(record); }} style={{ color: '#de99fd' }} type="copy" />
            <Icon style={{ color: '#ef5d5d' }} type="delete" />
          </span>
        );
      },
    }, {
      title: '软件类型',
      dataIndex: 'softwareType',
      key: 'softwareType',
    }, {
      title: '模块信息',
      dataIndex: 'moduleInfo',
      key: 'moduleInfo',
    }];
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };
    return (
      <div className="InputDetail_stepsContent">
        <div style={{ float: 'right', width: 100, height: 40 }}>
          <Button type="primary" onClick={() => this.setState({})}>编辑</Button>
        </div>
        <div style={{ width: '80%', marginLeft: '12%', minHeight: 500, marginTop: 20 }}>
          <div className="SoftwareInfoDetail_detail" >
            <div className="DeploymentSchemeDetail_headerpic">
              <span>调配方案</span>
            </div>
            <div className="SoftwareInfoDetail_content">
              <h2 style={{ display: 'inline-block' }}>声呐定位指示软件</h2>
              <time style={{ float: 'right' }} >{InitialData.time}</time>
              <div className="DeploymentSchemeDetail_brief">
                <span>编号：</span>
                <span>{InitialData.number}</span>
                <span>研制单位：</span>
                <span>{InitialData.developmentUnit}</span>
                <span>软件：</span>
                <span>{InitialData.softwareName}</span>
                <span>状态：</span>
                <span>{InitialData.status}</span>
              </div>
              <div>
                {InitialData.content}
              </div>
              <div style={{ marginTop: 10 }}>
                <span>附件：</span>
                <Link style={{ marginLeft: 15 }} >{InitialData.file[0]}</Link>
                <Link style={{ marginLeft: 15 }} >{InitialData.file[1]}</Link>
              </div>
            </div>
          </div>
          <div style={{ paddingBottom: 10, borderBottom: '1px solid #ccc' }}>
            <h2 style={{ margin: '20px 20px', display: 'inline-block' }}>调配申请列表</h2>
            <Search
              style={{ width: 380, height: 40, float: 'right', marginTop: 12 }}
            />
            <Table
              rowSelection={rowSelection}
              columns={columns}
              dataSource={this.state.dataSource}
              pagination={{ pageSize: 10 }}
              bordered
            />
          </div>
          <div style={{ paddingBottom: 10, borderBottom: '1px solid #ccc' }}>
            <h2 style={{ margin: '20px 20px', display: 'inline-block' }}>调配方案详情</h2>
            <Table
              rowSelection={rowSelection}
              columns={deploymentSchemeColumns}
              dataSource={this.state.deploymentSchemeData}
              pagination={{ pageSize: 10 }}
              bordered
              defaultExpandAllRows
            />
          </div>
        </div>
      </div>
    );
  }
}

// DeploymentSchemeDetailFirstRead.propTypes = {
//   disable: PropTypes.bool.isRequired,
//   form: PropTypes.object.isRequired,
// };
export default DeploymentSchemeDetailFirstRead;
