import React, { PropTypes } from 'react';
// import { Link } from 'react-router';
import { Select, TreeSelect, Button, Form, Input, Row, Upload, Icon, Col } from 'antd';

const FormItem = Form.Item;
class DeploymentSchemeDetailFirstEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      initialData: {
        oddNumbers: 'CL-20170427-0001',
        makeUnit: 'XX日常管理部门',
        registeUnit: '中船重工XX研究所',
        schemeName: '应用软件xx调配方案',
        taskSourse: 'DD2017051102111-调度任务',
        handler: '李四',
        softwarename: '指示软件',
        ancestary: '参数测量软件',
        saveCode: 'ltuirt89498324',
        Md5Confirm: 'ljudsery8347d',
        relativeFile: '无',
        distribution: '张三',
        InfoExplain: '软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役软件退役',
      },
      ancestaryTreeData: [{
        label: '应用软件',
        value: '0-0',
        key: '0-0',
        children: [{
          label: '参数测量软件',
          value: '0-0-1',
          key: '0-0-1',
        }, {
          label: '参数测量软件',
          value: '0-0-2',
          key: '0-0-2',
        }],
      }, {
        label: '参数测量软件',
        value: '0-1',
        key: '0-1',
      }],
    };
  }
  componentWillMount() {
    if (this.props.newStatus) {
      this.setState({ initialData: {} });
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const formItemLayoutDec = {
      labelCol: { span: 3 },
      wrapperCol: { span: 19 },
    };
    return (
      <div className="RetireDetail_stepsContent">
        <Form onSubmit={this.handleSubmit} style={{ width: '80%', marginLeft: '10%', minHeight: 500 }}>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件调配方案信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="编号"
              >
                <span>{this.state.initialData.oddNumbers}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="制定单位"
              >
                <span>{this.state.initialData.makeUnit}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="方案名称"
              >
                {getFieldDecorator('schmeName', {
                  initialValue: this.state.initialData.schemeName,
                  rules: [{ required: true, message: '请输入方案名称' }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="任务来源"
              >
                {getFieldDecorator('saveInfo', {
                  initialValue: this.state.initialData.taskSourse,
                  rules: [{ required: true, message: '请输入任务来源' }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件名称"
              >
                {getFieldDecorator('softwarename', {
                  initialValue: this.state.initialData.softwarename,
                  rules: [{
                    required: true,
                    message: '请输入软件名称!',
                    type: 'array',
                  }],
                })(
                  <Select mode="multiple">
                    <Option value="定位软件">定位软件1</Option>
                    <Option value="指示软件">指示软件</Option>
                    <Option value="导航软件">导航软件</Option>
                    <Option value="引导软件">引导软件</Option>
                    <Option value="扫描软件">扫描软件</Option>
                    <Option value="策略生成">策略生成</Option>
                    <Option value="定位计算">定位计算</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="谱系"
              >
                {getFieldDecorator('ancestary', {
                  initialValue: this.state.initialData.ancestary,
                  rules: [{ required: true, message: '请输入谱系!' }],
                })(
                  <TreeSelect
                    style={{ width: 356 }}
                    value={this.state.value}
                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                    treeData={this.state.ancestaryTreeData}
                    treeDefaultExpandAll
                    onChange={this.onChange}
                  />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="相关文件"
                hasFeedback
              >
                {getFieldDecorator('relativeFile', {
                  rules: [{ required: true, message: '请点击上传相关附件' }],
                })(
                  <Upload>
                    <Button>
                      <Icon type="upload" />点击上传
                    </Button>
                  </Upload>
                )}
              </FormItem>
            </Col>
            <Col span={24}>
              <FormItem
                {...formItemLayoutDec}
                label="方案描述"
              >
                {getFieldDecorator('softwareDescription', {
                  initialValue: this.state.initialData.InfoExplain,
                  rules: [{ required: true, message: '请输入方案描述' }],
                })(
                  <Input type="textarea" rows={10} />
                )}
              </FormItem>
            </Col>
          </Row>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>调配方案提交信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="处理人"
              >
                <span>{this.state.initialData.handler}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="选择任务分配人"
              >
                {getFieldDecorator('distribution', {
                  initialValue: this.state.initialData.distribution,
                  rules: [{ required: true, message: '请选择任务分配人' }],
                })(
                  <Select>
                    <Option value="定位软件">定位软件1</Option>
                    <Option value="指示软件">指示软件</Option>
                    <Option value="导航软件">导航软件</Option>
                    <Option value="引导软件">引导软件</Option>
                    <Option value="扫描软件">扫描软件</Option>
                    <Option value="策略生成">策略生成</Option>
                    <Option value="定位计算">定位计算</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={24}>
              <FormItem
                {...formItemLayoutDec}
                label="说明"
              >
                {getFieldDecorator('Description', {
                  rules: [{ required: true, message: '请输入方案描述' }],
                })(
                  <Input type="textarea" rows={10} />
                )}
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    );
  }
}

DeploymentSchemeDetailFirstEdit.propTypes = {
  form: PropTypes.object.isRequired,
  newStatus: PropTypes.bool.isRequired,
};
const WrapDeploymentSchemeDetailFirstEdit = Form.create()(DeploymentSchemeDetailFirstEdit);
export default WrapDeploymentSchemeDetailFirstEdit;
