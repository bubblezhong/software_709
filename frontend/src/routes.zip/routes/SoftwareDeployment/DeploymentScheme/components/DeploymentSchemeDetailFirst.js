import React, { PropTypes } from 'react';
import DeploymentSchemeDetailFirstEdit from './DeploymentSchemeDetailFirstEdit';
import DeploymentSchemeDetailFirstRead from './DeploymentSchemeDetailFirstRead';

class DeploymentSchemeDetailFirst extends React.Component {
  constructor(props) {
    super(props);
    console.log('disable', this.props.disable);
    this.state = {
      newStatus: true,
    };
  }
  render() {
    return (
      <div>
        {this.props.disable ?
          <DeploymentSchemeDetailFirstEdit newStatus={this.state.newStatus} /> :
            <DeploymentSchemeDetailFirstRead />
        }
      </div>
    );
  }
}
DeploymentSchemeDetailFirst.propTypes = {
  disable: PropTypes.bool.isRequired,
};
export default DeploymentSchemeDetailFirst;
