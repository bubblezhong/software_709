import { Table, Input, Button } from 'antd';
import React from 'react';
import { Link } from 'react-router';
import '../DeploymentScheme.css';
import { json2table } from './json2table';

const Search = Input.Search;
class DeploymentSchemeDetailFirstRead extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      InitialData: {
        content: '七○二所，1951年建立于上海黄浦江畔，1965年总部搬迁至无锡，在上海设有分部和青岛分部。数十年来建有功能齐全、配套完整的大中型科研试验设施近30座，设有两个国家级重点实验室，两个国家级检测中心，一个国家能源海洋工程装备研发中心和一个省级重点实验室，占地1300余亩，现有职工1500余人，其中拥有中国工程院院士2名， 国家“千人计划”1人，“万人计划”1人，“新世纪百千万人才工程”重点培养对象2人，国防科技工业511人才工程学术带头人2人，享受国务院政府津贴专家42名，省部级有突出贡献中青年专家19名。',
        number: 'MSSXL0678',
        developmentUnit: '中岸用软件-709所',
        softwareName: 'XX软件',
        file: ['附件1', '附件2'],
        status: '定制中',
      },
      dataSource: [{
        key: '1',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '2',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '3',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '4',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '5',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '6',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '7',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '8',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }, {
        key: '9',
        number: 'CL-20170427-0001',
        title: '应用软件问题汇总',
        applicant: '张三',
        unit: 'XX日常管理部门、XX机关',
        time: '2017/5/19 20:39',
        operate: '详情',
      }],
      deploymentSchemeData: [],
    };
  }
  componentWillMount() {
    const dataVertial = [
      {
        category: '岸基指挥所',
        group: [
          {
            organization: {
              name: 'XX指挥所',
              id: 529,
            },
            software: [
              {
                info: {
                  name: '指控设备',
                  id: 22,
                },
                position: '中空板',
                type: '岸用软件',
                modules: [
                  {
                    name: '总体模块',
                    id: 123,
                  },
                  {
                    name: '优化模块',
                    id: 233,
                  },
                  {
                    name: '解算模块',
                    id: 2334,
                  },
                ],
              },
              {
                info: {
                  name: '调配设备',
                  id: 24,
                },
                position: '中空板',
                type: '岸用软件',
                modules: [
                  {
                    name: '总体模块',
                    id: 123,
                  },
                  {
                    name: '优化模块',
                    id: 233,
                  },
                  {
                    name: '解算模块',
                    id: 2334,
                  },
                ],
              },
            ],
          },
          {
            organization: {
              name: 'YY指挥所',
              id: 529,
            },
            software: [
              {
                info: {
                  name: '指控设备',
                  id: 22,
                },
                position: '中空板',
                type: '岸用软件',
                modules: [
                  {
                    name: '总体模块',
                    id: 123,
                  },
                  {
                    name: '优化模块',
                    id: 233,
                  },
                  {
                    name: '解算模块',
                    id: 2334,
                  },
                ],
              },
              {
                info: {
                  name: '调配设备',
                  id: 24,
                },
                position: '中空板',
                type: '岸用软件',
                modules: [
                  {
                    name: '总体模块',
                    id: 123,
                  },
                  {
                    name: '优化模块',
                    id: 233,
                  },
                  {
                    name: '解算模块',
                    id: 2334,
                  },
                ],
              },
            ],
          },
        ],
        create_date: '2017-03-01 11:11:11',
        create_user: 12,
      },
    ];
    const tempViewList = json2table(dataVertial);
    this.setState({ deploymentSchemeData: tempViewList });
  }
  render() {
    const { InitialData } = this.state;
    const columns = [{
      title: '编号',
      dataIndex: 'number',
    }, {
      title: '调配申请标题',
      dataIndex: 'title',
    }, {
      title: '申请单位',
      dataIndex: 'unit',
    }, {
      title: '申请人',
      dataIndex: 'applicant',
    }, {
      title: '申请时间',
      dataIndex: 'time',
    }, {
      title: '操作',
      dataIndex: 'operate',
      render: (text, row) => <Link to={`/main/SoftwareDeployment/DeploymentRequestDetail/${row.key}`}>{text}</Link>,
    }];
    const deploymentSchemeColumns = [{
      title: '序号',
      dataIndex: 'number',
      render: (value, row) => {
        const obj = {
          children: value,
          props: {
            rowSpan: row.categoryRowSpan,
          },
        };
        return obj;
      },
    }, {
      title: '单位类别',
      dataIndex: 'unitType',
      render: (value, row) => {
        const obj = {
          children: value,
          props: {
            rowSpan: row.categoryRowSpan,
          },
        };
        return obj;
      },
    }, {
      title: '单位',
      dataIndex: 'unit',
    }, {
      title: '软件安装位置',
      dataIndex: 'installPos',
    }, {
      title: '软件类型',
      dataIndex: 'softwareType',
      key: 'softwareType',
    }, {
      title: '模块信息',
      dataIndex: 'moduleInfo',
      key: 'moduleInfo',
      render: (value) => {
        const result = (
          <ul>
            {value.map((item, i) => (<span key={i} style={{ marginRight: 10 }}>{item.name}</span>))}
          </ul>
        );
        return result;
      },
    }];
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      getCheckboxProps: record => ({
        disabled: record.name === 'Disabled User',    // Column configuration not to be checked
      }),
    };
    return (
      <div className="InputDetail_stepsContent">
        <div style={{ float: 'right', width: 100, height: 40 }}>
          <Button type="primary" onClick={() => this.setState({})}>编辑</Button>
        </div>
        <div style={{ width: '80%', marginLeft: '12%', minHeight: 500, marginTop: 20 }}>
          <div className="SoftwareInfoDetail_detail" >
            <div className="DeploymentSchemeDetail_headerpic">
              <span>调配方案</span>
            </div>
            <div className="SoftwareInfoDetail_content">
              <h2>声呐定位指示软件</h2>
              <div className="DeploymentSchemeDetail_brief">
                <span>编号：</span>
                <span>{InitialData.number}</span>
                <span>研制单位：</span>
                <span>{InitialData.developmentUnit}</span>
                <span>软件：</span>
                <span>{InitialData.softwareName}</span>
                <span>状态：</span>
                <span>{InitialData.status}</span>
              </div>
              <div>
                {InitialData.content}
              </div>
              <div style={{ marginTop: 10 }}>
                <span>附件：</span>
                <Link style={{ marginLeft: 15 }} >{InitialData.file[0]}</Link>
                <Link style={{ marginLeft: 15 }} >{InitialData.file[1]}</Link>
              </div>
            </div>
          </div>
          <div style={{ paddingBottom: 10, borderBottom: '1px solid #ccc' }}>
            <h2 style={{ margin: '20px 20px', display: 'inline-block' }}>调配申请列表</h2>
            <Search
              style={{ width: 380, height: 40, float: 'right', marginTop: 12 }}
            />
            <Table
              rowSelection={rowSelection}
              columns={columns}
              dataSource={this.state.dataSource}
              pagination={{ pageSize: 10 }}
              bordered
            />
          </div>
          <div style={{ paddingBottom: 10, borderBottom: '1px solid #ccc' }}>
            <h2 style={{ margin: '20px 20px', display: 'inline-block' }}>调配方案详情</h2>
            <Table
              columns={deploymentSchemeColumns}
              dataSource={this.state.deploymentSchemeData}
              bordered
            />
          </div>
        </div>
      </div>
    );
  }
}

// DeploymentSchemeDetailFirstRead.propTypes = {
//   disable: PropTypes.bool.isRequired,
//   form: PropTypes.object.isRequired,
// };
export default DeploymentSchemeDetailFirstRead;
