import React, { PropTypes } from 'react';
// import { Link } from 'react-router';
import { Button, Form, Input, Cascader, Select, Row, Upload, Icon, Col, Tree } from 'antd';

const FormItem = Form.Item;
const Option = Select.Option;
const TreeNode = Tree.TreeNode;
class RetireDetailFirst extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      oddNumbers: 'CL-20170427-0001',
      applicant: '张三',
      applyUnit: '中船重工xx研究所',
      handlePerson: '李四',
      operateSystem: '塞班2.0',
      installPos: '中控板',
      matingSoftware: '无',
      softwareGrade: '内部保密',
      saveType: '自持',
      MD5Value: '259a2d1f68fef2c2b38eddd9b4eb2f10',
      taskSource: 'D578ug工作调度',
      auditor: '张溪搜',
      explain: '无',
      softwareName: '远程目标软件',
      module: '应用软件>C类应用软件>对下声呐定位',
      softwareVersion: 'V.2.4.1',
      installUnit: '中船重工101',
      file: '无',
    };
  }
  render() {
    const residences = [{
      value: '应用软件',
      label: '应用软件',
      children: [{
        value: '参数测量软件',
        label: '参数测量软件',
        children: [{
          value: '定位软件',
          label: '定位软件',
        }],
      }],
    }, {
      value: '向下定位软件',
      label: '向下定位软件',
      children: [{
        value: '深度测量软件',
        label: '深度测量软件',
        children: [{
          value: '扫描软件',
          label: '扫描软件',
        }],
      }],
    }];
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    };
    const formItemLayoutDesc = {
      labelCol: { span: 3 },
      wrapperCol: { span: 19 },
    };
    return (
      <div className="InputDetail_stepsContent">
        <Form onSubmit={this.handleSubmit} style={{ width: '80%', marginLeft: '10%', minHeight: 900 }}>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件退役申请单基本信息</div>
          {this.props.disable ?
            <Row>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="单号"
                  hasFeedback
                >
                  <span>{this.state.oddNumbers}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="申请人"
                  hasFeedback
                >
                  <span>{this.state.applicant}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="申请单位"
                  hasFeedback
                >
                  <span>{this.state.applyUnit}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="处理人"
                  hasFeedback
                >
                  <span>{this.state.handlePerson}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="任务来源"
                  hasFeedback
                >
                  <span>{this.state.taskSource}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="审核人"
                  hasFeedback
                >
                  <span>{this.state.auditor}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="说明"
                >
                  <span>{this.state.explain}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="附件"
                  hasFeedback
                >
                  <span>{this.state.file}</span>
                </FormItem>
              </Col>
            </Row> :
              <Row>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="单号"
                    hasFeedback
                  >
                    <span>{this.state.oddNumbers}</span>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="申请人"
                    hasFeedback
                  >
                    <span>{this.state.applicant}</span>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="申请单位"
                    hasFeedback
                  >
                    <span>{this.state.applyUnit}</span>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="处理人"
                    hasFeedback
                  >
                    <span>{this.state.handlePerson}</span>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="任务来源"
                    hasFeedback
                  >
                    {getFieldDecorator('taskSource', {
                      rules: [{ required: true, message: 'Please select your developUnit!' }],
                    })(
                      <Select>
                        <Option value="DD2017051102112升级完善任务">DD2017051102112升级完善任务</Option>
                        <Option value="DD2017051102112调度任务">DD2017051102112调度任务</Option>
                        <Option value="03-yy中队指挥所">03-yy中队指挥所</Option>
                        <Option value="04-yy中队指挥所">04-yy中队指挥所</Option>
                        <Option value="05-yy中队指挥所">05-yy中队指挥所</Option>
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="选择审核人"
                    hasFeedback
                  >
                    {getFieldDecorator('applyUnit', {
                      rules: [{ required: true, message: 'Please select your developUnit!' }],
                    })(
                      <Select>
                        <Option value="张三">张三</Option>
                        <Option value="李四">李四</Option>
                        <Option value="王五">王五</Option>
                        <Option value="张三1">张三1</Option>
                        <Option value="王五2">王五2</Option>
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col span={24}>
                  <FormItem
                    {...formItemLayoutDesc}
                    label="说明"
                  >
                    {getFieldDecorator('softwareDescription', {
                      rules: [{ required: true, message: '请输入相关说明' }],
                    })(
                      <Input type="textarea" rows={10} />
                    )}
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="附件"
                    hasFeedback
                  >
                    {getFieldDecorator('file', {
                      rules: [{ required: true, message: '请点击上传附件' }],
                    })(
                      <Upload>
                        <Button>
                          <Icon type="upload" />点击上传
                        </Button>
                      </Upload>
                    )}
                  </FormItem>
                </Col>
              </Row>
          }
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>退役软件基本信息</div>
          {this.props.disable ?
            <Row>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="软件名称"
                  hasFeedback
                >
                  <span>{this.state.softwareName}</span>
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="谱系"
                >
                  <span>{this.state.module}</span>
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="软件版本"
                >
                  <span>{this.state.softwareVersion}</span>
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="软件安装单位"
                  hasFeedback
                >
                  <span>{this.state.installUnit}</span>
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem
                  {...formItemLayout}
                  label="软件模块关系"
                >
                  {getFieldDecorator('moduleRelation', {
                    rules: [
                      { message: '请输入软件模块关系' },
                    ],
                  })(
                    <Tree
                      style={{ marginTop: -15 }}
                      showLine
                      defaultExpandedKeys={['0-0-0']}
                      onSelect={this.onSelect}
                    >
                      <TreeNode title="远程目标软件" key="0-0">
                        <TreeNode title="模块优化" key="0-0-0">
                          <TreeNode title="模块优化" key="0-0-0-0" />
                        </TreeNode>
                        <TreeNode title="目标指示模块" key="0-0-1">
                          <TreeNode title="声呐控制" key="0-0-1-0" />
                        </TreeNode>
                        <TreeNode title="总体生成" key="0-0-2">
                          <TreeNode title="leaf" key="0-0-2-0" />
                          <TreeNode title="leaf" key="0-0-2-1" />
                        </TreeNode>
                        <TreeNode title="策略生成" key="0-0-3">
                          <TreeNode title="leaf" key="0-0-3-0" />
                          <TreeNode title="leaf" key="0-0-3-1" />
                        </TreeNode>
                      </TreeNode>
                    </Tree>
                    )}
                </FormItem>
              </Col>
            </Row> :
              <Row>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="软件名称"
                    hasFeedback
                  >
                    {getFieldDecorator('softwarename', {
                      rules: [{
                        required: true, message: '请输入软件名称!',
                      }],
                    })(
                      <Select>
                        <Option value="定位软件">定位软件1</Option>
                        <Option value="指示软件">指示软件</Option>
                        <Option value="导航软件">导航软件</Option>
                        <Option value="引导软件">引导软件</Option>
                        <Option value="扫描软件">扫描软件</Option>
                        <Option value="策略生成">策略生成</Option>
                        <Option value="定位计算">定位计算</Option>
                      </Select>
                    )}
                  </FormItem>
                  <FormItem
                    {...formItemLayout}
                    label="谱系"
                  >
                    {getFieldDecorator('ancestary', {
                      initialValue: ['zhejiang', 'hangzhou', 'xihu'],
                      rules: [{ type: 'array', required: true, message: '请输入谱系!' }],
                    })(
                      <Cascader options={residences} />
                    )}
                  </FormItem>
                  <FormItem
                    {...formItemLayout}
                    label="软件版本"
                  >
                    {getFieldDecorator('softwareVersion', {
                      rules: [{ required: true, message: '请选择软件版本!' }],
                    })(
                      <Select placeholder="请选择软件版本">
                        <Option value="V3.1.1.1">V3.1.1.1</Option>
                        <Option value="V.2.7.1.1">V.2.7.1.1</Option>
                        <Option value="V.2.1.2.3">V.2.1.2.3</Option>
                        <Option value="V.4.1.1.1">V.4.1.1.1</Option>
                        <Option value="V.3.2.1.1">V.3.2.1.1</Option>
                      </Select>
                    )}
                  </FormItem>
                  <FormItem
                    {...formItemLayout}
                    label="软件安装单位"
                    hasFeedback
                  >
                    {getFieldDecorator('installUnit', {
                      rules: [{ required: true, message: 'Please select your developUnit!' }],
                    })(
                      <Select>
                        <Option value="DD2017051102112升级完善任务">DD2017051102112升级完善任务</Option>
                        <Option value="DD2017051102112调度任务">DD2017051102112调度任务</Option>
                        <Option value="03-yy中队指挥所">03-yy中队指挥所</Option>
                        <Option value="04-yy中队指挥所">04-yy中队指挥所</Option>
                        <Option value="05-yy中队指挥所">05-yy中队指挥所</Option>
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem
                    {...formItemLayout}
                    label="软件模块关系"
                  >
                    {getFieldDecorator('moduleRelation', {
                      rules: [
                        { message: '请输入软件模块关系' },
                      ],
                    })(
                      <Tree
                        style={{ marginTop: -15 }}
                        showLine
                        defaultExpandedKeys={['0-0-0']}
                        onSelect={this.onSelect}
                      >
                        <TreeNode title="远程目标软件" key="0-0">
                          <TreeNode title="模块优化" key="0-0-0">
                            <TreeNode title="模块优化" key="0-0-0-0" />
                          </TreeNode>
                          <TreeNode title="目标指示模块" key="0-0-1">
                            <TreeNode title="声呐控制" key="0-0-1-0" />
                          </TreeNode>
                          <TreeNode title="总体生成" key="0-0-2">
                            <TreeNode title="leaf" key="0-0-2-0" />
                            <TreeNode title="leaf" key="0-0-2-1" />
                          </TreeNode>
                          <TreeNode title="策略生成" key="0-0-3">
                            <TreeNode title="leaf" key="0-0-3-0" />
                            <TreeNode title="leaf" key="0-0-3-1" />
                          </TreeNode>
                        </TreeNode>
                      </Tree>
                      )}
                  </FormItem>
                </Col>
              </Row>
          }
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>退役软件描述信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="操作系统"
                hasFeedback
              >
                <span>{this.state.operateSystem}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="典型安装位置"
              >
                {getFieldDecorator('select-multiple', {
                  rules: [
                    { message: '请输入典型安装位置!' },
                  ],
                })(
                  <span>{this.state.installPos}</span>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="配套软件"
              >
                {getFieldDecorator('matingSoftware', {
                  rules: [
                    { message: '请输入配套软件' },
                  ],
                })(
                  <span>{this.state.matingSoftware}</span>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件等级"
                hasFeedback
              >
                {getFieldDecorator('softwareGrade', {
                  rules: [{
                    message: '请输入软件等级',
                  }],
                })(
                  <span>{this.state.softwareGrade}</span>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="存储方式"
                hasFeedback
              >
                {getFieldDecorator('saveType', {
                  rules: [{ message: '请输入代码规模' }],
                })(
                  <span>{this.state.saveType}</span>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="MD5校验值"
                hasFeedback
              >
                {getFieldDecorator('MD5Value', {
                  rules: [{ message: '请输入MD5校验值' }],
                })(
                  <span>{this.state.MD5Value}</span>
                )}
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    );
  }
}

RetireDetailFirst.propTypes = {
  form: PropTypes.object.isRequired,
  disable: PropTypes.bool.isRequired,
};
const WrapRetireDetailFirst = Form.create()(RetireDetailFirst);
export default WrapRetireDetailFirst;
