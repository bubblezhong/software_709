import React from 'react';
import { Button, Input } from 'antd';

const Search = Input.Search;
const ButtonGroup = Button.Group;


const App = () => (
  <div style={{ overflow: 'auto', marginBottom: 10 }}>
    <ButtonGroup style={{ float: 'left' }}>
      <Button icon="reload" style={{ width: 110, height: 40, fontSize: 14 }}>刷新</Button>
      <Button icon="file-add" style={{ width: 110, height: 40, fontSize: 14 }}>申请入库</Button>
      <Button icon="login" style={{ width: 110, height: 40, fontSize: 14 }}>导入</Button>
      <Button icon="logout" style={{ width: 110, height: 40, fontSize: 14 }}>导出</Button>
      <Button icon="printer" style={{ width: 110, height: 40, fontSize: 14 }}>打印</Button>
      <Button icon="delete" style={{ width: 110, height: 40, fontSize: 14 }}>撤销</Button>
    </ButtonGroup>
    <Search
      placeholder="搜索软件名称、申请单位等"
      style={{ width: 380, height: 40, float: 'right' }}
      onSearch={value => console.log(value)}
    />
  </div>
);


export default App;
