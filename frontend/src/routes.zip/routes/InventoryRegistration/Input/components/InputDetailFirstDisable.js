import React, { PropTypes } from 'react';
// import { Link } from 'react-router';
import { Button, Form, Input, Cascader, Select, Row, Radio, Upload, Icon, Col, TreeSelect } from 'antd';

const FormItem = Form.Item;
const Option = Select.Option;
const SHOW_PARENT = TreeSelect.SHOW_PARENT;
class InputDetailFirst extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      confirmDirty: false,
      autoCompleteResult: [],
      oddNumbers: 'CL-20170427-0001',
      applicant: '张三',
      applyUnit: '中船重工xx研究所',
      handlePerson: '李四',
      treeData: [{
        label: '声呐定位指示软件',
        value: '0-0',
        key: '0-0',
        children: [{
          label: '优化模块',
          value: '0-0-0',
          key: '0-0-0',
        }],
      }, {
        label: '优化模块',
        value: '0-1',
        key: '0-1',
        children: [{
          label: '目标指示模块',
          value: '0-1-0',
          key: '0-1-0',
        }, {
          label: '声呐控制',
          value: '0-1-1',
          key: '0-1-1',
        }, {
          label: '总体模块',
          value: '0-1-2',
          key: '0-1-2',
        }],
      }],
    };
  }
  render() {
    const residences = [{
      value: '应用软件',
      label: '应用软件',
      children: [{
        value: '参数测量软件',
        label: '参数测量软件',
        children: [{
          value: '定位软件',
          label: '定位软件',
        }],
      }],
    }, {
      value: '向下定位软件',
      label: '向下定位软件',
      children: [{
        value: '深度测量软件',
        label: '深度测量软件',
        children: [{
          value: '扫描软件',
          label: '扫描软件',
        }],
      }],
    }];
    const tProps = {
      treeData: this.state.treeData,
      multiple: true,
      treeCheckable: true,
      showCheckedStrategy: SHOW_PARENT,
      searchPlaceholder: 'Please select',
      style: {
        width: 300,
      },
    };
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 5 },
      wrapperCol: { span: 15 },
    };
    console.log(this.props.disable);
    return (
      <div className="InputDetail_stepsContent">
        <Form onSubmit={this.handleSubmit} style={{ width: '80%', marginLeft: '10%', minHeight: 900 }}>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件入库申请单基本信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="单号"
                hasFeedback
              >
                <span>{this.state.oddNumbers}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="申请人"
                hasFeedback
              >
                <span>{this.state.applicant}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="申请单位"
                hasFeedback
              >
                <span>{this.state.applyUnit}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="处理人"
                hasFeedback
              >
                <span>{this.state.handlePerson}</span>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="任务来源"
                hasFeedback
              >
                {getFieldDecorator('taskSource', {
                  rules: [{ required: true, message: 'Please select your developUnit!' }],
                })(
                  <Select>
                    <Option value="DD2017051102112升级完善任务">DD2017051102112升级完善任务</Option>
                    <Option value="DD2017051102112调度任务">DD2017051102112调度任务</Option>
                    <Option value="03-yy中队指挥所">03-yy中队指挥所</Option>
                    <Option value="04-yy中队指挥所">04-yy中队指挥所</Option>
                    <Option value="05-yy中队指挥所">05-yy中队指挥所</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="选择审核人"
                hasFeedback
              >
                {getFieldDecorator('applyUnit', {
                  rules: [{ required: true, message: 'Please select your developUnit!' }],
                })(
                  <Select>
                    <Option value="张三">张三</Option>
                    <Option value="李四">李四</Option>
                    <Option value="王五">王五</Option>
                    <Option value="张三1">张三1</Option>
                    <Option value="王五2">王五2</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="说明"
              >
                {getFieldDecorator('softwareDescription', {
                  rules: [{ required: true, message: '请输入相关说明' }],
                })(
                  <Input type="textarea" rows={10} />
                )}
              </FormItem>
            </Col>
          </Row>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件基本信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件名称"
                hasFeedback
              >
                {getFieldDecorator('softwarename', {
                  rules: [{
                    required: true, message: '请输入软件名称!',
                  }],
                })(
                  <Select>
                    <Option value="定位软件">定位软件1</Option>
                    <Option value="指示软件">指示软件</Option>
                    <Option value="导航软件">导航软件</Option>
                    <Option value="引导软件">引导软件</Option>
                    <Option value="扫描软件">扫描软件</Option>
                    <Option value="策略生成">策略生成</Option>
                    <Option value="定位计算">定位计算</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件单元名称"
                hasFeedback
              >
                {getFieldDecorator('categoryName', {
                  rules: [{
                    required: true, message: '请输入谱系!',
                  }],
                })(
                  <Select>
                    <Option value="定位软件">定位软件1</Option>
                    <Option value="指示软件">指示软件</Option>
                    <Option value="导航软件">导航软件</Option>
                    <Option value="引导软件">引导软件</Option>
                    <Option value="扫描软件">扫描软件</Option>
                    <Option value="策略生成">策略生成</Option>
                    <Option value="定位计算">定位计算</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="谱系"
              >
                {getFieldDecorator('ancestary', {
                  initialValue: ['zhejiang', 'hangzhou', 'xihu'],
                  rules: [{ type: 'array', required: true, message: '请输入谱系!' }],
                })(
                  <Cascader options={residences} />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件单元版本"
              >
                {getFieldDecorator('categoryVersion', {
                  initialValue: ['zhejiang', 'hangzhou', 'xihu'],
                  rules: [{ type: 'array', required: true, message: '请输入谱系!' }],
                })(
                  <Cascader options={residences} />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件等级"
              >
                {getFieldDecorator('softwareGrade', {
                  rules: [{ required: true, message: '请输入软件等级!' }],
                })(
                  <Select>
                    <Option value="公开">公开</Option>
                    <Option value="内部公开">内部公开</Option>
                    <Option value="保密">保密</Option>
                    <Option value="机密">机密</Option>
                    <Option value="秘密">秘密</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件模块关系"
              >
                {getFieldDecorator('moduleRelation', {
                  rules: [
                    { required: true, message: '请输入软件模块关系', type: 'array' },
                  ],
                })(
                  <TreeSelect {...tProps} />
                  )}
              </FormItem>
            </Col>
          </Row>
          <div style={{ marginBottom: 20, marginTop: 20, marginLeft: '3%', width: '90%', height: 50, backgroundColor: '#edf7fc', lineHeight: '50px', paddingLeft: 20 }}>软件描述信息</div>
          <Row>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="操作系统"
                hasFeedback
              >
                {getFieldDecorator('OperateSystem', {
                  rules: [{ required: true, message: '请输入典型操作系统！' }],
                })(
                  <Select>
                    <Option value="radhat">radhat</Option>
                    <Option value="linux">linux</Option>
                    <Option value="centOS">centOS</Option>
                    <Option value="Windows">Windows</Option>
                    <Option value="塞班">塞班</Option>
                    <Option value="Android">Android</Option>
                    <Option value="ubuntu">ubuntu</Option>
                    <Option value="其他">其他</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="典型安装位置"
              >
                {getFieldDecorator('select-multiple', {
                  rules: [
                    { required: true, message: '请输入典型安装位置!', type: 'array' },
                  ],
                })(
                  <Select mode="multiple">
                    <Option value="中控板">中控板</Option>
                    <Option value="交叉控制板">交叉控制板</Option>
                    <Option value="指挥中心">指挥中心</Option>
                    <Option value="其他">其他</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="配套软件"
              >
                {getFieldDecorator('matingSoftware', {
                  rules: [
                    { required: true, message: '请输入配套软件', type: 'array' },
                  ],
                })(
                  <Select mode="multiple">
                    <Option value="定位软件">定位软件</Option>
                    <Option value="指示软件">指示软件</Option>
                    <Option value="导航软件">导航软件</Option>
                    <Option value="引导软件">引导软件</Option>
                    <Option value="扫描软件">扫描软件</Option>
                    <Option value="测试软件">测试软件</Option>
                    <Option value="航速判读软件">航速判读软件</Option>
                  </Select>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="存储位置"
                hasFeedback
              >
                {getFieldDecorator('savePos', {
                  rules: [{
                    required: true, message: '请输入存储位置',
                  }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="代码规模"
                hasFeedback
              >
                {getFieldDecorator('codeSize', {
                  rules: [{ required: true, message: '请输入代码规模' }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="MD5校验值"
                hasFeedback
              >
                {getFieldDecorator('MD5Value', {
                  rules: [{ required: true, message: '请输入MD5校验值' }],
                })(
                  <Input />
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="存储方式"
              >
                <Row gutter={8}>
                  <Radio.Group>
                    <Radio value="自持">自持</Radio>
                    <Radio value="网络存储">网络存储</Radio>
                  </Radio.Group>
                </Row>
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="附件"
                hasFeedback
              >
                {getFieldDecorator('represent_install_pos', {
                  rules: [{ required: true, message: '请点击上传附件' }],
                })(
                  <Upload>
                    <Button>
                      <Icon type="upload" />点击上传
                    </Button>
                  </Upload>
                )}
              </FormItem>
            </Col>
            <Col span={12}>
              <FormItem
                {...formItemLayout}
                label="软件描述"
              >
                {getFieldDecorator('softwareDescription', {
                  rules: [{ required: true, message: '请输入软件描述' }],
                })(
                  <Input type="textarea" rows={10} />
                )}
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    );
  }
}

InputDetailFirst.propTypes = {
  form: PropTypes.object.isRequired,
  disable: PropTypes.bool.isRequired,
};
const WrapInputDetailFirst = Form.create()(InputDetailFirst);
export default WrapInputDetailFirst;
