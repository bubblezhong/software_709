import Input from './Input/Input';
import InputDetail from './Input/InputDetail';
import InputList from './Input/List';
import OutputList from './Output/List';
import OutputDetail from './Output/OutputDetail';
import RetireList from './Retire/List';
import RetireDetail from './Retire/RetireDetail';

// 软件库存登记管理
const routes = {
  path: 'InventoryRegistration',
  component: Input,
  name: '软件库存登记管理',
  indexRoute: {
    component: InputList,
  },
  target: 'InventoryRegistration',
  childRoutes: [
    {
      path: 'Input',
      name: '软件入库',
      component: InputList,
    },
    {
      path: 'InputDetail/:id',
      name: '软件入库',
      component: InputDetail,
    },
    {
      path: 'Output',
      name: '软件出库',
      component: OutputList,
    },
    {
      path: 'OutputDetail/:id',
      name: '软件入库',
      component: OutputDetail,
    },
    {
      path: 'Retire',
      name: '软件退役',
      component: RetireList,
    },
    {
      path: 'RetireDetail/:id',
      name: '软件入库',
      component: RetireDetail,
    },
  ],
};


export default routes;
