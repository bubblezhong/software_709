import React, { Component } from 'react';
import './UndoTask/UndoTask.css';

class Operate extends React.Component {
  constructor(props) {
    super(props);
  }
  render(){
    return(
      <div>
        <button>刷新</button>
      </div>
  )
  }
}
export default Operate;
