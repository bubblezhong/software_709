import React from 'react';
import MesList from './MesRemind/MesList';

const MesRemind = () => {
  return (
    <div>
      <MesList />
    </div>
  );
};

export default MesRemind;
