import React from 'react';

class UserSetting extends React.Component {
  render() {
    console.log('ShowingSetting');
    return (
      <div style={{ top: '50%', left: '50%' }}>UserSetting</div>
    );
  }
}
export default UserSetting;
