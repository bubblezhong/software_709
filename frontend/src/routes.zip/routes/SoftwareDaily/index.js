import SoftwareDaily from './SoftwareDaily';
import Collect from './Collect/Collect';
// import CollectDetail from './Collect/Detail';
import Registration from './Registration/Registration';
// import RegistrationEdit from './Registration/Edit';
// import RegistrationNew from './Registration/New';
// import RegistrationDetail from './Registration/Detail';

const routes = {
  path: 'SoftwareDaily',
  name: '软件日常管理',
  component: SoftwareDaily,
  indexRoute: {
    component: Registration,
  },
  childRoutes: [
    {
      path: 'Collect',
      name: '登记汇总',
      component: Collect,
    }, {
      path: 'Registration',
      name: '日常登记',
      component: Registration,
    },
  ],
};

export default routes;
