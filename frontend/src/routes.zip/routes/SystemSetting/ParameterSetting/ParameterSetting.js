import React, { PropTypes } from 'react';
import { Form, Input, Button } from 'antd';
import '../SystemSetting.css';

const FormItem = Form.Item;

class ParameterSetting extends React.Component {
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
      }
    });
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 10 },
    };
    const formTitleLayout = {
      labelCol: { span: 2 },
      wrapperCol: { span: 10 },
    };
    const formFooterLayout = {
      labelCol: { span: 2 },
      wrapperCol: { span: 18 },
    };
    return (
      <Form onSubmit={this.handleSubmit} className="login-form">
        <div>
          <FormItem
            {...formTitleLayout}
            style={{ backgroundColor: '#edf7fc' }}
            label="基本信息"
          />
          <FormItem {...formItemLayout} label="系统标题">
            {getFieldDecorator('SystemTitle', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="系统URL地址">
            {getFieldDecorator('UrlSize', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="cookie加密码">
            {getFieldDecorator('CookiePassword', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="数据库url">
            {getFieldDecorator('DatabaseUrl', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="数据库用户名">
            {getFieldDecorator('DatabaseName', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="数据库密码">
            {getFieldDecorator('DatabasePassword', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
        </div>
        <div>
          <FormItem
            {...formTitleLayout}
            style={{ backgroundColor: '#edf7fc' }}
            label="高级信息"
          />
          <FormItem {...formItemLayout} label="SMTP服务器的用户邮箱">
            {getFieldDecorator('ServerEmail', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="SMTP服务器的用户账号">
            {getFieldDecorator('ServerAccount', {
              rules: [{
                required: true,
              }],
            })(
              <Input />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="SMTP服务器的用户密码">
            {getFieldDecorator('ServerPassword', {
              rules: [{
                required: true,
              }],
            })(
              <Input type="password" />
            )}
          </FormItem>
        </div>
        <div>
          <FormItem {...formFooterLayout}>
            {getFieldDecorator('ServerPassword', {})(
              <div>
                <Button type="primary" htmlType="submit">Search</Button>
                <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
                  Clear
                </Button>
              </div>
            )}
          </FormItem>
        </div>
      </Form>
    );
  }
}
ParameterSetting.propTypes = {
  form: PropTypes.object.isRequired,
};
const WrapParameterSetting = Form.create()(ParameterSetting);
export default WrapParameterSetting;
