import ParameterSetting from './ParameterSetting/ParameterSetting';
import OrganizationStructure from './OrganizationStructure/OrganizationStructure';
import UserManage from './UserManage/UserManage';
import RoleManage from './RoleManage/RoleManage';
import MenuManage from './MenuManage/MenuManage';
import AuthorityManage from './AuthorityManage/AuthorityManage';
import ProcessConfiguration from './ProcessConfiguration/ProcessConfiguration';
import Backup from './Backup/Backup';
import RecordInfo from './RecordInfo/RecordInfo';

const config = {
  path: 'SystemSetting',
  name: '系统设置',
  target: 'SystemSetting', // 用于数据分流 标志 √
  indexRoute: {
    component: ParameterSetting,
  },
  childRoutes: [
    {
      path: 'ParameterSetting',
      name: '参数设置',
      component: ParameterSetting,
    },
    {
      path: 'OrganizationStructure',
      name: '组织结构',
      component: OrganizationStructure,
    },
    {
      path: 'UserManage',
      name: '用户管理',
      component: UserManage,
    },
    {
      path: 'RoleManage',
      name: '角色管理',
      component: RoleManage,
    },
    {
      path: 'MenuManage',
      name: '菜单管理',
      component: MenuManage,
    },
    {
      path: 'AuthorityManage',
      name: '权限管理',
      component: AuthorityManage,
    },
    {
      path: 'ProcessConfiguration',
      name: '流程配置',
      component: ProcessConfiguration,
    },
    {
      path: 'Backup',
      name: '初始化备份',
      component: Backup,
    },
    {
      path: 'RecordInfo',
      name: '日志信息',
      component: RecordInfo,
    },
  ],
};

export default config;
