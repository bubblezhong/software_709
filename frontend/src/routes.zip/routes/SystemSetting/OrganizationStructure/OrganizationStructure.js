import React from 'react';
import { Table, Button, Input } from 'antd';

const ButtonGroup = Button.Group;
const Search = Input.Search;

class OrganizationStructure extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{
        key: 1,
        name: '中船重工研究所',
        num: '01',
        unitType: '研发单位',
        personInCharge: '李四',
        SuperiorID: '00',
        sort: '1',
        operate: '详情',
        children: [{
          key: 11,
          name: '中船重工研究所',
          num: '01',
          unitType: '研发单位',
          personInCharge: '李四',
          SuperiorID: '00',
          sort: '1',
          operate: '详情',
        }, {
          key: 12,
          name: '中船重工研究所',
          num: '01',
          unitType: '研发单位',
          personInCharge: '李四',
          SuperiorID: '00',
          sort: '1',
          operate: '详情',
          children: [{
            key: 121,
            name: '中船重工研究所',
            num: '01',
            unitType: '研发单位',
            personInCharge: '李四',
            SuperiorID: '00',
            sort: '1',
            operate: '详情',
          }],
        }, {
          key: 13,
          name: '中船重工研究所',
          num: '01',
          unitType: '研发单位',
          personInCharge: '李四',
          SuperiorID: '00',
          sort: '1',
          operate: '详情',
          children: [{
            key: 131,
            name: '中船重工研究所',
            num: '01',
            unitType: '研发单位',
            personInCharge: '李四',
            SuperiorID: '00',
            sort: '1',
            operate: '详情',
            children: [{
              key: 1311,
              name: '中船重工研究所',
              num: '01',
              unitType: '研发单位',
              personInCharge: '李四',
              SuperiorID: '00',
              sort: '1',
              operate: '详情',
            }, {
              key: 1312,
              name: '中船重工研究所',
              num: '01',
              unitType: '研发单位',
              personInCharge: '李四',
              SuperiorID: '00',
              sort: '1',
              operate: '详情',
            }],
          }],
        }],
      }, {
        key: 2,
        name: '中船重工研究所',
        num: '01',
        unitType: '研发单位',
        personInCharge: '李四',
        SuperiorID: '00',
        sort: '1',
        operate: '详情',
      }],
    };
  }
  render() {
    const Btns = (
      <div>
        <ButtonGroup style={{ marginBottom: 10 }}>
          <Button icon="reload" style={{ width: 110, height: 40, fontSize: 14 }}>刷新</Button>
          <Button icon="file-add" style={{ width: 110, height: 40, fontSize: 14 }}>新增下级</Button>
          <Button icon="login" style={{ width: 110, height: 40, fontSize: 14 }}>导入</Button>
          <Button icon="logout" style={{ width: 110, height: 40, fontSize: 14 }}>导出</Button>
          <Button icon="printer" style={{ width: 110, height: 40, fontSize: 14 }}>打印</Button>
          <Button icon="delete" style={{ width: 110, height: 40, fontSize: 14 }}>删除</Button>
        </ButtonGroup>
        <Search
          placeholder="搜索软件名称、申请单位等"
          style={{ width: 380, height: 40, float: 'right' }}
          onSearch={value => console.log(value)}
        />
      </div>
    );
    const columns = [{
      title: '名称',
      dataIndex: 'name',
      key: 'name',
    }, {
      title: '编号',
      dataIndex: 'num',
      key: 'num',
    }, {
      title: '单位类型',
      dataIndex: 'unitType',
      key: 'unitType',
    }, {
      title: '负责人',
      dataIndex: 'personInCharge',
      key: 'personInCharge',
    }, {
      title: '上级ID',
      dataIndex: 'SuperiorID',
      key: 'unitname',
    }, {
      title: '排序号',
      dataIndex: 'sort',
      key: 'sort',
    }, {
      title: '操作',
      dataIndex: 'operate',
      key: 'operate',
      render: () => (
        <span>
          <span style={{ fontWeight: 900, marginLeft: 10 }}>X &nbsp;&nbsp;&nbsp;</span>
          <a style={{ fontWeight: 500 }} >&gt;&gt;</a>
        </span>
      ),
    }];
  // rowSelection objects indicates the need for row selection
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
      },
      onSelect: (record, selected, selectedRows) => {
        console.log(record, selected, selectedRows);
      },
      onSelectAll: (selected, selectedRows, changeRows) => {
        console.log(selected, selectedRows, changeRows);
      },
    };
    return (
      <div>
        {Btns}
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={this.state.data}
          pagination={{ pageSize: 10 }}
          bordered
        />
      </div>
    );
  }
}


export default OrganizationStructure;
